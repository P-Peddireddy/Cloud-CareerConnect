package com.careerconnect;

public class UploadCv {



    public String getUrl() {
        return url;
    }

    public UploadCv(String url ) {

        this.url = url;
    }


    public String url;



}
